import os
import csv

cereal_csv = os.path.join("../Resources", "cereal.csv")
